#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="UserAssemblyType.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.Utilities.Editor.CodeGeneration
{
    /// <summary>
    /// Not yet documented.
    /// </summary>
    public enum UserAssemblyType
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        Standard,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        StandardEditor,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        Plugin,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        PluginEditor
    }
}
#endif